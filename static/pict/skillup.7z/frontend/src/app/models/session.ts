export class Session {
  id: number;
  userName: string;
  access_token: string;
}
