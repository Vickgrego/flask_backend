export enum NavigationActionType {
  Content = 1,
  Navigation,
  ContentUrl
}
