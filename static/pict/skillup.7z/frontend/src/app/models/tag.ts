export class Tag {
  id: number;
  tagGroupId: number;
  tagGroupName: string;
  name: string;
  orderNumber: number;
  isActive: boolean;
}
