import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lending-page',
  templateUrl: './lending-page.component.html',
  styleUrls: ['./lending-page.component.scss']
})
export class LendingPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
