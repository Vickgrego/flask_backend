export const environment = {
  production: false,
  apiAdmin: 'http://avalaadminwsdev.azurewebsites.net/api',
  apiSite: 'http://avalawsdev.azurewebsites.net/api'
};
