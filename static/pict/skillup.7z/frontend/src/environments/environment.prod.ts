export const environment = {
  production: true,
  apiAdmin: 'http://avalaadminws.azurewebsites.net/api',
  apiSite: 'http://avalaws.azurewebsites.net/api'
};
